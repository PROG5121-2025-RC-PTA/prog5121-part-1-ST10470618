/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog5121poe_part2;

import java.security.SecureRandom;
import java.util.regex.Pattern;
/**
 *
 * @author RC_Student_lab
 */
public class Prog5121poe_Part2 {

    public class Message {
    private String messageID;
    private String recipient;
    private String messageContent;
    private String messageHash;

    // Constructor
    public Message(String recipient, String messageContent) {
        this.recipient = recipient;
        this.messageContent = messageContent;
        // MessageID and Hash are generated/updated by MessageService
        // They are initialized here but their final value depends on processing.
        this.messageID = generateMessageID(); // Initial ID, might be updated later
        this.messageHash = ""; // Will be set by MessageService with sequence number
    }

    // --- Getters ---
    public String getMessageID() {
        return messageID;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessageContent() {
        return messageContent;
    }

    public String getMessageHash() {
        return messageHash;
    }

    // --- Setters (for service to update) ---
    public void setMessageID(String messageID) {
        this.messageID = messageID;
    }

    public void setMessageHash(String messageHash) {
        this.messageHash = messageHash;
    }

    // --- Methods as per requirements ---

    // Private helper to generate a random 10-digit message ID
    private String generateMessageID() {
        SecureRandom random = new SecureRandom();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            sb.append(random.nextInt(10)); // 0-9
        }
        return sb.toString();
    }

    // Boolean: checkMessageID() - Ensures message ID is not more than ten characters.
    // This is primarily for validating an ID from an external source if needed.
    public boolean checkMessageIDFormat() {
        return this.messageID != null && this.messageID.length() <= 10;
    }

    /**
     * Int: checkRecipientCell() - Ensures recipient cell number is no more than ten characters long
     * and starts with an international code (assuming '+').
     * Returns:
     * 0: Valid
     * 1: Empty/null recipient
     * 2: Too long (more than 10 chars)
     * 3: Does not start with '+'
     * 4: Contains non-digit characters after '+' or incorrect total length (if not 10 chars, starting with +)
     */
    public int checkRecipientCell() {
        if (recipient == null || recipient.isEmpty()) {
            return 1; // Empty/null recipient
        }
        if (recipient.length() > 10) {
            return 2; // Too long
        }
        // Assuming international code starts with '+' and then 9 digits for a 10 char length
        if (!Pattern.matches("^\\+\\d{9}$", recipient)) {
            return 3; // Doesn't match expected pattern (e.g., doesn't start with +, or not 9 digits after +)
        }
        return 0; // Valid
    }

    /**
     * String: createMessageHash() - Creates and returns the Message Hash.
     * This version requires the messageSequenceNum to be passed.
     */
    public String createMessageHash(int messageSequenceNum) {
        if (messageID == null || messageID.length() < 2 || messageContent == null || messageContent.isEmpty()) {
            return ""; // Handle cases where ID or content might be invalid
        }

        String firstTwoID = messageID.substring(0, 2);
        String[] words = messageContent.trim().split("\\s+"); // Split by one or more spaces
        String firstWord = "";
        String lastWord = "";

        if (words.length > 0) {
            // Clean words from punctuation if necessary
            firstWord = words[0].replaceAll("[^a-zA-Z0-9]", "").toUpperCase();
            lastWord = words[words.length - 1].replaceAll("[^a-zA-Z0-9]", "").toUpperCase();
        }

        return firstTwoID + ":" + messageSequenceNum + ":" + firstWord + lastWord;
    }

    // Method to check message content length
    public String checkMessageLength() {
        if (messageContent == null || messageContent.isEmpty()) {
            return "Please enter a message."; // Custom error for empty message
     }
        if (messageContent.length() > 250) {
            int excess = messageContent.length() - 250;
            return "Message exceeds 250 characters by " + excess + ", please reduce size.";
        }
        // Assuming a minimum length for a "short message" (e.g., more than just spaces)
        if (messageContent.trim().length() == 0) {
            return "Please enter a non-empty message.";
        }
        return "Message ready to send."; // Success
    }

    // Method to return formatted message details for display
    public String getFormattedMessageDetails() {
        return "Message ID: " + messageID + "\n" +
               "Message Hash: " + messageHash + "\n" +
               "Recipient: " + recipient + "\n" +
               "Message: " + messageContent;
    }

    // For JSON serialization
    public String toJSONString() {
        // Simple JSON string for demonstration. For production, consider Gson/Jackson.
        return String.format(
                "{\"messageID\": \"%s\", \"recipient\": \"%s\", \"messageContent\": \"%s\", \"messageHash\": \"%s\"}", messageID, recipient, messageContent, messageHash
            
        );
    }
}
     

