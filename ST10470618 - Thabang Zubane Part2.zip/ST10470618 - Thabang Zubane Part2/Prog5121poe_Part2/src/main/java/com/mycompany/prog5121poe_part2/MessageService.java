/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog5121poe_part2;

import com.mycompany.prog5121poe_part2.Prog5121poe_Part2.Message;
import javax.swing.JOptionPane;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author RC_Student_lab
 */
public class MessageService {
    private List<Message> sentMessages;
    private int totalMessagesSent; // Counter for messages genuinely sent/processed
    private Object[] options;

    public MessageService() {
        this.sentMessages = new ArrayList<>();
        this.totalMessagesSent = 0;
    }

    public int getTotalMessagesSent() {
        return totalMessagesSent;
    }

    public List<Message> getSentMessages() {
        return new ArrayList<>(sentMessages); // Return a copy to prevent external modification
    }

    /**
     * Processes a message: validates, generates hash, and handles user action.
     * @param message The Message object to process.
     * @return true if the message was successfully 'sent' (added to sentMessages list), false otherwise.
     */
    public boolean processMessage(Message message) {
        // 1. Validate Message Length
        String lengthValidationResult = message.checkMessageLength();
        if (!lengthValidationResult.equals("Message ready to send.")) {
            JOptionPane.showMessageDialog(null, lengthValidationResult, "Message Length Error", JOptionPane.ERROR_MESSAGE);
            return false; // Invalid message length, do not proceed
        }

        // 2. Validate Recipient
        int recipientValidationResult = message.checkRecipientCell();
        if (recipientValidationResult != 0) {
            String errorMsg = "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.\n";
            switch (recipientValidationResult) {
                case 1: errorMsg += "Recipient number cannot be empty."; break;
                case 2: errorMsg += "Recipient number is too long (max 10 characters)."; break;
                case 3: errorMsg += "Recipient number must start with '+' and have 9 digits."; break;
                case 4: errorMsg += "Recipient number contains invalid characters or has an incorrect length after '+'."; break;
            }
            JOptionPane.showMessageDialog(null, errorMsg, "Recipient Validation Error", JOptionPane.ERROR_MESSAGE);
            return false; // Invalid recipient, do not proceed
        }

        // Message is valid, increment counter and generate hash
        totalMessagesSent++;
        // Update the Message object with the correct hash and its unique sequence number
        message.setMessageHash(message.createMessageHash(totalMessagesSent));

        // 3. User Action Prompt
        String[] messageOptions = {"Send Message", "Disregard Message", "Store Message to send later"};
        int messageChoice = JOptionPane.showOptionDialog(
                null,
                "Message details:\n" + message.getFormattedMessageDetails() + "\n\nWhat would you like to do with this message?",
                "Message Action",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                messageOptions,
                options[0] // Default to "Send Message"
        );

        switch (messageChoice) {
            case 0: // Send Message
                sentMessages.add(message);
                JOptionPane.showMessageDialog(null, "Message sent successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                JOptionPane.showMessageDialog(null, message.getFormattedMessageDetails(), "Sent Message Details", JOptionPane.INFORMATION_MESSAGE);
                return true;
            case 1: // Disregard Message
                JOptionPane.showMessageDialog(null, "Message disregarded.", "Info", JOptionPane.INFORMATION_MESSAGE);
                totalMessagesSent--; // Decrement as it wasn't truly sent/processed
                return false;
            case 2: // Store Message to send later (JSON)
                storeMessageInJson(message);
                JOptionPane.showMessageDialog(null, "Message stored for later sending.", "Info", JOptionPane.INFORMATION_MESSAGE);
                totalMessagesSent--; // Decrement as it wasn't truly sent in this session
                return false;
            case JOptionPane.CLOSED_OPTION:
                JOptionPane.showMessageDialog(null, "Message action cancelled. Disregarding current message.", "Cancellation", JOptionPane.WARNING_MESSAGE);
                totalMessagesSent--; // Decrement as it wasn't truly sent
                return false;
            default:
                // Should not happen with showOptionDialog
                return false;
        }
    }

    // Method to store message in JSON
    private void storeMessageInJson(Message message) {
        String fileName = "stored_messages.json";
        try (FileWriter file = new FileWriter(fileName, true)) { // true for append mode
            file.write(message.toJSONString() + "\n");
            System.out.println("Message successfully stored to " + fileName);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "An error occurred while storing the message: " + e.getMessage(), "File Write Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // This method is for the 'printMessages()' requirement, which lists all messages sent during program run.
    public String getAllSentMessagesDetails() {
        if (sentMessages.isEmpty()) {
            return "No messages have been sent yet in this session.";
        }
        StringBuilder sb = new StringBuilder("--- All Sent Messages in Current Session ---\n");
        for (Message msg : sentMessages) {
            sb.append(msg.getFormattedMessageDetails()).append("\n-------------------------\n");
        }
        return sb.toString();
    }
}
    
