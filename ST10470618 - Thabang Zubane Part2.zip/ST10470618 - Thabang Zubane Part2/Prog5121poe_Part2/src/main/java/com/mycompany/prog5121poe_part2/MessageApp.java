/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog5121poe_part2;

import com.mycompany.prog5121poe_part2.Prog5121poe_Part2.Message;
import javax.swing.JOptionPane;

/**
 *
 * @author RC_Student_lab
 */
public class MessageApp {
     private static MessageService messageService = new MessageService();

    public static void main(String[] args) {
        // Simulating a successful login for now.
        // In a real app, you'd have actual login logic.
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat.", "Welcome", JOptionPane.INFORMATION_MESSAGE);

        boolean running = true;
        while (running) {
            String[] options = {"Send Messages", "Show Recently Sent Messages (Coming Soon)", "Quit"};
            int choice = JOptionPane.showOptionDialog(
                    null,
                    "Please choose an option:",
                    "QuickChat Menu",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null, // No custom icon
                    options,
                    options[0] // Default selected option
            );

            switch (choice) {
                case 0: // Send Messages
                    sendMessagesWorkflow();
                    break;
                case 1: // Show Recently Sent Messages (Coming Soon)
                    JOptionPane.showMessageDialog(null, "This feature is still in development: \"Coming Soon.\"", "Feature Status", JOptionPane.INFORMATION_MESSAGE);
                    // Optionally, you could also show the list of messages in current session here:
                    // JOptionPane.showMessageDialog(null, messageService.getAllSentMessagesDetails(), "Sent Messages History", JOptionPane.INFORMATION_MESSAGE);
                    break;
                case 2: // Quit
                    running = false;
                    JOptionPane.showMessageDialog(null, "Thank you for using QuickChat. Goodbye!", "Exiting", JOptionPane.INFORMATION_MESSAGE);
                    break;
                case JOptionPane.CLOSED_OPTION: // User clicked the 'X' button to close the dialog
                    running = false;
                    JOptionPane.showMessageDialog(null, "Application closed. Goodbye!", "Exiting", JOptionPane.INFORMATION_MESSAGE);
                    break;
                default:
                    // This case should ideally not be reached with showOptionDialog
                    JOptionPane.showMessageDialog(null, "An unexpected error occurred. Please restart the application.", "Error", JOptionPane.ERROR_MESSAGE);
                    running = false; // Exit to prevent infinite loop on unexpected input
                    break;
            }
        }
    }

    private static void sendMessagesWorkflow() {
        String numMessagesStr = JOptionPane.showInputDialog(null, "How many messages do you wish to enter?", "Number of Messages", JOptionPane.QUESTION_MESSAGE);
        int numMessagesToEnter;
        try {
            if (numMessagesStr == null) { // User clicked cancel or closed dialog
                JOptionPane.showMessageDialog(null, "Message entry cancelled.", "Info", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            numMessagesToEnter = Integer.parseInt(numMessagesStr);
            if (numMessagesToEnter <= 0) {
                JOptionPane.showMessageDialog(null, "Please enter a positive number of messages.", "Invalid Input", JOptionPane.WARNING_MESSAGE);
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid number.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        for (int i = 0; i < numMessagesToEnter; i++) {
            String recipient = JOptionPane.showInputDialog(null, "Enter recipient's cell number (e.g., +27123456789):", "Enter Recipient", JOptionPane.QUESTION_MESSAGE);
            if (recipient == null) { // User cancelled this message
                JOptionPane.showMessageDialog(null, "Message entry cancelled for current message.", "Info", JOptionPane.INFORMATION_MESSAGE);
                continue; // Move to the next message or finish loop
            }

            String messageContent = JOptionPane.showInputDialog(null, "Enter your message (max 250 characters):", "Enter Message", JOptionPane.QUESTION_MESSAGE);
            if (messageContent == null) { // User cancelled this message
                JOptionPane.showMessageDialog(null, "Message entry cancelled for current message.", "Info", JOptionPane.INFORMATION_MESSAGE);
                continue; // Move to the next message or finish loop
            }

            Message newMessage = new Message(recipient, messageContent);

            // Process the message through the service
            messageService.processMessage(newMessage); // This handles all validation, hash, and user action
        }

        // Display total messages sent after the loop concludes
        JOptionPane.showMessageDialog(null, "Total messages processed (sent/stored): " + messageService.getTotalMessagesSent(), "Session Summary", JOptionPane.INFORMATION_MESSAGE);
    }
}
