/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog5121poe;

/**
 *
 * @author RC_Student_lab
 */
public class Login {
  public static boolean checkUserName(String pUserName) {
        if(pUserName.length()<=5 && pUserName.contains("_")){
            System.out.println(pUserName);
            return true;
        }
        else {
            return false;
        }
    }
    
    public static boolean checkPasswordComplexity(String pPassword) {
        boolean hasDigit = false;
        boolean hasUppercase = false;
        boolean hasSpecialCharacter = false;
        
        for (int i = 0; i < pPassword.length(); i++) {
            char c = pPassword.charAt(i);
            
            if (Character.isDigit(c)) {
                hasDigit = true;
            } else if (Character.isUpperCase(c)) {
                hasUppercase = true;
            } else if ("!@#$%^&*()|[]\\:\";'<>?,./".indexOf(c) != -1) {
                hasSpecialCharacter = true;
            }
        }
        
        return hasDigit && hasUppercase && hasSpecialCharacter && pPassword.length() >=8;
    }
    public static String registerUser(String pUsername, String pPassword) {
    if (!checkUserName(pUsername)) {
        return "Invalid username";
    }
    if (!checkPasswordComplexity(pPassword)) {
        return "Invalid password";
    }
    return "Registration successful";
}
public static boolean loginUser(String pLoginUser, String pLoginPass, String pUserName, String pPassword)
    {
        if (pLoginUser.equals(pUserName) && pLoginPass.equals(pPassword))
        {
            return true;
        } else {
            return false;
        }
    }

    public static String returnLoginStatus(String pLoginUser, String pLoginPass, String pUserName, String pPassword, String pFirstName, String pLastName) 
    {
        if (loginUser(pLoginUser, pLoginPass, pUserName, pPassword))      
        {
            return "Username or password is incorrect, please try again";
        } else {
            return "Welcome " + pFirstName + ", " + pLastName + " it is great to see you again.";
        }
    }
    
    
}
