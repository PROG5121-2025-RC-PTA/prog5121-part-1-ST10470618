/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog5121poe;

import java.util.Scanner;

/**
 *
 * @author RC_Student_lab
 */
public class Prog5121poe {

 public static void main(String[] args) {
        createAccount();
    }
    public static void createAccount() {
        
        String firstName;
        String lastName;
        String userName;
        String password;
        Scanner keyboard = new Scanner(System.in);
        
        System.out.println("Enter your first name: ");
        firstName = keyboard.nextLine();
        System.out.println("Enter your last name: ");
        lastName = keyboard.nextLine();
        System.out.println("Create your username: ");
        userName = keyboard.nextLine();
        System.out.println("Create your password: ");
        password = keyboard.nextLine();
        
        System.out.println(com.mycompany.prog5121poe.Login.registerUser(userName, password));
        
        login(userName, password, firstName, lastName);
    }
    
    public static void login(String pUserName, String pPassword, String pFirstName, String pLastName ){
        String loginUser;
        String loginPass;
        Scanner keyboard = new Scanner(System.in);
        
        System.out.println("Login");
        System.out.println("Enter the Username");
        loginUser = keyboard.nextLine();
        System.out.println("Enter the Password");
        loginPass = keyboard.nextLine();
        
        System.out.println(com.mycompany.prog5121poe.Login.returnLoginStatus(loginUser, loginPass, pUserName, pPassword, pFirstName, pLastName));
    }
}
